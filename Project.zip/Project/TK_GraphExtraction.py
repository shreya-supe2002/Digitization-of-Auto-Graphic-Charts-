import cv2
import numpy as np
import matplotlib.pyplot as plt
from datetime import timedelta
import datetime
import matplotlib.dates as mdates
import matplotlib.dates as md
import matplotlib.ticker as plticker

import datetime as dt
import time
import tkinter
from pandas import DataFrame
import array
import datetime





from datetime import datetime, timedelta
def datetime_range(start, end, delta):
    current = start
    while current < end:
        yield current
        current += delta



def mapValue( x,  in_min,  in_max,  out_min,  out_max):
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min


def ProcessImage(source, destination):

    #!wget  https://i.stack.imgur.com/sDQLM.png
    #read image 
    image = cv2.imread( source)


    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV) 
    lower_blue = np.array([110,50,50]) 
    upper_blue = np.array([130,255,255]) 

    # Here we are defining range of bluecolor in HSV 
    # This creates a mask of blue coloured  
    # objects found in the frame. 
    mask = cv2.inRange(hsv, lower_blue, upper_blue) 

    # The bitwise and of the frame and mask is done so  
    # that only the blue coloured objects are highlighted  
    # and stored in res 
    res = cv2.bitwise_and(image,image, mask= mask) 
    #cv2.imshow('frame',image) 
    #####cv2.imshow('mask',mask) 
    #cv2.imshow('res',res) 

    # do connected components processing
    nlabels, labels, stats, centroids = cv2.connectedComponentsWithStats(mask, None, None, None, 8, cv2.CV_32S)

    #get CC_STAT_AREA component as stats[label, COLUMN] 
    areas = stats[1:,cv2.CC_STAT_AREA]

    result = np.zeros((labels.shape), np.uint8)

    for i in range(0, nlabels - 1):
        if areas[i] >= 100:   #keep
            result[labels == i + 1] = 255

    #cv2.imshow("Binary", mask)
    #cv2.imshow("Result", result)
    #cv2.waitKey(0)

    active_pixels = np.stack(np.where(result))
    top_left = np.min(active_pixels, axis=1).astype(np.int32)
    bottom_right = np.max(active_pixels, axis=1).astype(np.int32)

    print(top_left)
    print(bottom_right)
    # Plot them
    #for keypoint in [top_left, bottom_right]:
    #    y, x = keypoint
    #    cv2.drawMarker(image, (x, y), 255, markerType=cv2.MARKER_TILTED_CROSS, markerSize=10, thickness=2)

    #cv2.imshow('image', image)

    #cv2.waitKey(0)
    crop = result[top_left[0]:bottom_right[0],top_left[1]:bottom_right[1]] 
    cv2.imshow('crop Image', crop)  

    print("Graph Size")
    print(crop.shape)

    MinTemp = 16
    MaxTemp = 29
    t1 = timedelta(hours=8, minutes=15)
    t2 = timedelta(hours=8, minutes=14)

    arrival = t2 - t1


    print(arrival)
    #exit()
    tempRange = MaxTemp-MinTemp

    temp = []

    for y in range(crop.shape[1]):
        start = -1
        end = -1
        for x in range(crop.shape[0]):
             if(crop[x, y] > 250 and start == -1):
                start = x
                end = x;
             
             if(crop[x, y] > 250 and start > -1):
                end = x
             crop[x, y] = 0
                
        #print('Start = ', start)
        #print('end = ', end)
        if(start != -1 ):
            target = end-start
            traget = target/2
            traget = traget+start
            #print('target = ', traget)
            crop[int(traget), y] = 255
            
            temp.append(mapValue(traget, crop.shape[0], 0, MinTemp, MaxTemp))
    
    
            
        #print('---------------------------------------------')  

    Temp_np =  np.array(temp)

    cv2.imshow('crop Image  after line', crop)  
    cv2.waitKey(0)
    #x = [datetime.now() + datetime.timedelta(minutes=i) for i in range(1315)]

    # Puts x-axis labels on an angle
    #           plt.gca().xaxis.set_tick_params(rotation = 1)  

    # Changes x-axis range

    n=len(Temp_np)            
    duration=86399   


    t = (2023, 4, 20, 8, 15, 00, 1, 48, 0)
    
    
    
    
    
    
    
      
    # Parse the time string using 
    # time.strptime() method 

    now=time.mktime(t)
    timestamps=np.linspace(now,now+duration,n)

    print(len(timestamps))
    dates=[dt.datetime.fromtimestamp(ts) for ts in timestamps]
    print(len(dates))
    print((dates[0].time()))
    print(dates[0])
    times = []
    for h in range(len(dates)):
        times.append(dates[h].time())
        
     
    datenums=md.date2num(dates)
    plt.subplots_adjust(bottom=0.2)
    plt.xticks( rotation = 25 )
    ax=plt.gca()
    xfmt = md.DateFormatter('%H:%M:%S')#%Y-%m-%d 
    ax.xaxis.set_major_formatter(xfmt)
    
    print("-------------------------")
    print(len(datenums))
    print(len(Temp_np))
    print(xfmt)
    
    timestamp = []
    
    hr = int(n/24)
    print("hr = " + str(hr))

    #df = DataFrame({'Time': times[0:n], 'Temp.': Temp_np[0:n]})
    finelTime = []
    finalTemp = []
    for h in range(25):
        finelTime.append(times[int(hr*h)])
        finalTemp.append(Temp_np[int(hr*h)])
        print(int(hr*h))
    df = DataFrame({'Time': finelTime[0:24], 'Temp.': finalTemp[0:24]})
    df.to_excel(destination, sheet_name='sheet1', index=False)
    plt.plot(datenums, Temp_np)
    loc = plticker.MultipleLocator(base=0.1) # this locator puts ticks at regular intervals
    ax.xaxis.set_major_locator(loc)
    plt.show()




