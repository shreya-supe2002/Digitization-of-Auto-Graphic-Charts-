from tkinter import *
from tkinter import filedialog
from pathlib import Path
from PIL import Image, ImageTk
import TK_GraphExtraction as ge

sourceFile = ""
destinationFile = ""


def browseFiles():
    global sourceFile
    filename = filedialog.askopenfilename(initialdir="/",
                                          title="Select a File",
                                          filetypes=(("Image files", "*.jpg*"), ("All files", "*.*")))
    if filename:
        sourceFile = filename
        s_label_file_explorer.configure(text="File Opened: " + filename)


def browseFolder():
    global destinationFile
    folder_path = filedialog.askdirectory()
    if folder_path:
        destinationFile = folder_path
        d_label_file_explorer.configure(text="Folder Selected: " + folder_path)


def runModule():
    global destinationFile, sourceFile

    if sourceFile and destinationFile:
        filename = Path(sourceFile).stem
        destinationFile = (destinationFile + '/' + filename + '.xlsx')
        ge.ProcessImage(sourceFile, destinationFile)
        run_button_explore.configure(text="Proceed", state="disabled")
        # You can integrate the progress bar logic here
        # For simplicity, I'm just disabling the button during processing.


def resize_background(event):
    background_label.place(relx=0, rely=0, relwidth=1, relheight=1)


# Create the root window
window = Tk()
window.title('File Explorer')
window.geometry("700x500")

# Add background image
background_image = Image.open("BackGround_Image.jfif")
background_image = background_image.resize((700, 500), Image.ANTIALIAS)
background_image = ImageTk.PhotoImage(background_image)

background_label = Label(window, image=background_image)
background_label.place(relx=0, rely=0, relwidth=1, relheight=1)

# Custom Fonts
font_style = ("Helvetica", 12, "bold")

# Add Heading
heading_label = Label(window, text="Digitization of autographic chart", font=("Helvetica", 16, "bold"), bg="#f0f0f0")
heading_label.place(relx=0.5, rely=0.1, anchor=CENTER)

# Add Logo
im = Image.open("IMD_logo.jfif")
im = im.resize((200, 200), Image.ANTIALIAS)
im = ImageTk.PhotoImage(im)

logo_label = Label(window, image=im, bg="#f0f0f0")
logo_label.place(relx=0.5, rely=0.3, anchor=CENTER)

# Create a File Explorer label
s_label_file_explorer = Label(window, text="Source", width=30, height=2, fg="black", font=font_style,
                              bg="#EBEDEF")  # White background
s_label_file_explorer.place(relx=0.3, rely=0.5, anchor=CENTER)

d_label_file_explorer = Label(window, text="Destination", width=30, height=2, fg="black", font=font_style,
                              bg="#EBEDEF")  # White background
d_label_file_explorer.place(relx=0.3, rely=0.6, anchor=CENTER)

s_button_explore = Button(window, text="Browse Files", command=browseFiles, bg="#4caf50", fg="white",
                          font=font_style)  # Green background
s_button_explore.place(relx=0.5, rely=0.5, anchor=CENTER)

d_button_explore = Button(window, text="Browse Folder", command=browseFolder, bg="#4caf50", fg="white",
                          font=font_style)
d_button_explore.place(relx=0.5, rely=0.6, anchor=CENTER)

run_button_explore = Button(window, text="Proceed", command=runModule, bg="#C0392B", fg="white",
                            font=font_style)  # Orange background
run_button_explore.place(relx=0.5, rely=0.7, anchor=CENTER)


img = Image.open("IMD-Pune-Building.webp")
img= img.resize((650,200), Image.ANTIALIAS)
img = ImageTk.PhotoImage(img)

logo_label = Label(window, image=img, bg="#f0f0f0")
logo_label.place(relx=0.5, rely=0.9, anchor=CENTER)

window.bind('<Configure>', resize_background)

window.mainloop()
